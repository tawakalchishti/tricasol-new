<?php 
  
  $title = "Website Security | Tricasol";
  $description="Website security is critical component to protect and secure websites and servers. Websites are scanned for any possible vulnerabilities and malware through ...";
  $keyword="";

  include('header.php'); 

?>
  <section class="inner-page-banner overflow-hidden position-relative m-auto">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-12">
          <div class="visual-content">
            <h2 class="text-uppercase">Website Security</h2>
            <!-- <span class="d-block text-white mb-3">Web Hosting Plans</span> -->
          </div>
          <div class="btn-scroll-down">
			<a href="javascript:void(0);" data-bind="scrollTo" data-target="#btn-scroll-down">
				<i class="fa fa-chevron-down"></i>
			</a>
		</div>
        </div>
        
      </div>
    </div>
  </section>
  <main>



  </main>
  
<?php include('footer.php'); ?>